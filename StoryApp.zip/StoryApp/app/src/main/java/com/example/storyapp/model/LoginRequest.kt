package com.example.storyapp.model

data class LoginRequest(
   var email : String,
   var password : String
)
