package com.example.storyapp.view

import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.storyapp.databinding.ActivityMainBinding
import com.example.storyapp.model.*
import com.example.storyapp.utils.UserPreference
import com.example.storyapp.view.adapter.ListStoryAdapter
import com.example.storyapp.viewmodel.ListStoryViewModel

var INI_TOKEN = ""

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val listStoryViewModel by viewModels<ListStoryViewModel>()


    companion object {
        const val CAMERA_X_RESULT = 200
        private val REQUIRED_PERMISSIONS = arrayOf(android.Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this,
                    "Tidak mendapatkan permission.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super .onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        val userPreference = UserPreference(this@MainActivity)
        val sharedPreferences = userPreference.getUser()

        if (sharedPreferences.token == "") {
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }else{
            INI_TOKEN = sharedPreferences.token.toString()
            listStoryViewModel.getStories("Bearer ${sharedPreferences.token}")
        }

        binding.buttonAddStory.setOnClickListener {
            val intent = Intent(this@MainActivity, UploadStoryActivity::class.java)
            startActivity(intent)
        }

        binding.logoutButton.setOnClickListener {
            val logout = userPreference.clearUser()
            if (logout) {
                Toast.makeText(this@MainActivity, "Logout Success", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@MainActivity, LoginActivity::class.java)
                intent.putExtra("isLogout", true)
                startActivity(intent)
                finish()
            }

        }

        listStoryViewModel.stories.observe(this) {
            val adapter = ListStoryAdapter()
            adapter.setList(it.listStory as ArrayList<ListStoryItem>)
            binding.rvStory.layoutManager = LinearLayoutManager(this@MainActivity)
            binding.rvStory.adapter = adapter
        }

        listStoryViewModel.getStories(sharedPreferences.token.toString())

        listStoryViewModel.isLoading.observe(this) {
            binding.isLoading.visibility = if (it) android.view.View.VISIBLE else android.view.View.GONE
        }

        val onBackPressedCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (sharedPreferences.token != "") {
                    finishAffinity()
                }
            }
        }
        onBackPressedDispatcher.addCallback(this, onBackPressedCallback)

    }


}








